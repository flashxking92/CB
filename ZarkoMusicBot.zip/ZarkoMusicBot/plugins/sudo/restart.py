import asyncio
import os
import shutil

from git import Repo
from git.exc import GitCommandError, InvalidGitRepositoryError
from pyrogram import filters

import config
from ZarkoMusicBot import app
from ZarkoMusicBot.misc import SUDOERS
from ZarkoMusicBot.utils.database import (
    get_active_chats,
    remove_active_chat,
    remove_active_video_chat,
)
from ZarkoMusicBot.utils.decorators.language import language
from ZarkoMusicBot.utils.pastebin import NandBin


# ------------------ ʟᴏɢꜱ ------------------ #
@app.on_message(filters.command(["getlog", "logs", "getlogs"]) & SUDOERS)
@language
async def log_(client, message, _):
    try:
        if os.path.exists("log.txt"):
            await message.reply_document("log.txt")
        else:
            await message.reply_text("❌ ʟᴏɢ ꜰɪʟᴇ ɴᴏᴛ ꜰᴏᴜɴᴅ.")
    except Exception as e:
        await message.reply_text(f"❌ ᴇʀʀᴏʀ: {e}")


# ------------------ ᴜᴘᴅᴀᴛᴇ ------------------ #
@app.on_message(filters.command(["update", "gitpull"]) & SUDOERS)
@language
async def update_(client, message, _):
    response = await message.reply_text("🔄 ᴄʜᴇᴄᴋɪɴɢ ꜰᴏʀ ᴜᴘᴅᴀᴛᴇꜱ...")

    # ɢɪᴛ ʀᴇᴘᴏ ᴄʜᴇᴄᴋ
    try:
        repo = Repo()
    except InvalidGitRepositoryError:
        return await response.edit("❌ ɪɴᴠᴀʟɪᴅ ɢɪᴛ ʀᴇᴘᴏꜱɪᴛᴏʀʏ.")
    except GitCommandError:
        return await response.edit("❌ ɢɪᴛ ᴇʀʀᴏʀ ᴏᴄᴄᴜʀʀᴇᴅ.")

    # ꜰᴇᴛᴄʜ ʟᴀᴛᴇꜱᴛ
    os.system(f"git fetch origin {config.UPSTREAM_BRANCH} > /dev/null 2>&1")
    await asyncio.sleep(2)

    # ᴄʜᴇᴄᴋ ᴄᴏᴍᴍɪᴛꜱ
    commits = list(repo.iter_commits(f"HEAD..origin/{config.UPSTREAM_BRANCH}"))

    if not commits:
        return await response.edit("✅ ᴀʟʀᴇᴀᴅʏ ᴜᴘ-ᴛᴏ-ᴅᴀᴛᴇ.")

    updates = ""
    for i, commit in enumerate(commits, start=1):
        updates += f"{i}. {commit.summary}\n"

    # ꜱᴇɴᴅ ᴜᴘᴅᴀᴛᴇꜱ
    if len(updates) > 4000:
        url = await NandBin(updates)
        await response.edit(f"📄 ᴜᴘᴅᴀᴛᴇꜱ ᴛᴏᴏ ʟᴏɴɢ:\n{url}")
    else:
        await response.edit(f"🚀 ᴜᴘᴅᴀᴛᴇꜱ ᴀᴠᴀɪʟᴀʙʟᴇ:\n\n{updates}")

    # ᴘᴜʟʟ ᴜᴘᴅᴀᴛᴇꜱ
    os.system("git stash > /dev/null 2>&1 && git pull")

    # ɴᴏᴛɪꜰʏ ᴀᴄᴛɪᴠᴇ ᴄʜᴀᴛꜱ
    try:
        chats = await get_active_chats()
        for chat in chats:
            try:
                await app.send_message(
                    int(chat),
                    f"{app.mention} 🔄 ʙᴏᴛ ᴜᴘᴅᴀᴛᴇᴅ! ʀᴇꜱᴛᴀʀᴛɪɴɢ..."
                )
                await remove_active_chat(chat)
                await remove_active_video_chat(chat)
            except:
                pass
    except:
        pass

    await response.edit("✅ ᴜᴘᴅᴀᴛᴇ ᴄᴏᴍᴘʟᴇᴛᴇᴅ. ʀᴇꜱᴛᴀʀᴛɪɴɢ...")

    # ɪɴꜱᴛᴀʟʟ ᴅᴇᴘꜱ ꜱɪʟᴇɴᴛʟʏ
    os.system("pip3 install -r requirements.txt > /dev/null 2>&1")

    # ꜱᴀꜰᴇ ʀᴇꜱᴛᴀʀᴛ (ɴᴏ ᴋɪʟʟ -9)
    os.execv("/bin/bash", ["bash", "start"])


# ------------------ ʀᴇꜱᴛᴀʀᴛ ------------------ #
@app.on_message(filters.command(["restart"]) & SUDOERS)
async def restart_(client, message):
    msg = await message.reply_text("🔄 ʀᴇꜱᴛᴀʀᴛɪɴɢ ʙᴏᴛ...")

    # ɴᴏᴛɪꜰʏ ᴄʜᴀᴛꜱ
    try:
        chats = await get_active_chats()
        for chat in chats:
            try:
                await app.send_message(
                    int(chat),
                    f"{app.mention} 🔄 ʀᴇꜱᴛᴀʀᴛɪɴɢ...\n\nᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ 10-15 ꜱᴇᴄᴏɴᴅꜱ."
                )
                await remove_active_chat(chat)
                await remove_active_video_chat(chat)
            except:
                pass
    except:
        pass

    # ᴄʟᴇᴀɴ ꜰᴏʟᴅᴇʀꜱ ꜱᴀꜰᴇʟʏ
    for folder in ["downloads", "raw_files", "cache"]:
        try:
            if os.path.exists(folder):
                shutil.rmtree(folder)
        except:
            pass

    await msg.edit("✅ ʀᴇꜱᴛᴀʀᴛɪɴɢ...")

    # ꜱᴀꜰᴇ ʀᴇꜱᴛᴀʀᴛ
    os.execv("/bin/bash", ["bash", "start"])