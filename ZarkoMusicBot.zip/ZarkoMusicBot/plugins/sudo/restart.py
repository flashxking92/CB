import os
import shutil

from pyrogram import filters

import config
from ZarkoMusicBot import app
from ZarkoMusicBot.misc import SUDOERS
from ZarkoMusicBot.utils.database import (
    get_active_chats,
    remove_active_chat,
    remove_active_video_chat,
)
from ZarkoMusicBot.utils.decorators.language import language


# ================= ʟᴏɢꜱ ================= #

@app.on_message(filters.command(["getlog", "logs", "getlogs"]) & SUDOERS)
@language
async def log_(client, message, _):
    try:
        await message.reply_document("log.txt")
    except:
        await message.reply_text("ʟᴏɢ ꜰɪʟᴇ ɴᴏᴛ ꜰᴏᴜɴᴅ.")


# ================= ʀᴇꜱᴛᴀʀᴛ ================= #

@app.on_message(filters.command(["restart"]) & SUDOERS)
async def restart_(_, message):
    response = await message.reply_text("🔄 ʀᴇꜱᴛᴀʀᴛɪɴɢ ʙᴏᴛ...")

    # ɴᴏᴛɪꜰʏ ᴀᴄᴛɪᴠᴇ ᴄʜᴀᴛꜱ
    try:
        chats = await get_active_chats()
        for chat in chats:
            try:
                await app.send_message(
                    int(chat),
                    f"{app.mention} ɪꜱ ʀᴇꜱᴛᴀʀᴛɪɴɢ...\n\nᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ 10-15 ꜱᴇᴄᴏɴᴅꜱ.",
                )
                await remove_active_chat(chat)
                await remove_active_video_chat(chat)
            except:
                pass
    except:
        pass

    # ᴄʟᴇᴀɴᴜᴘ ꜰᴏʟᴅᴇʀꜱ
    for folder in ["downloads", "raw_files", "cache"]:
        try:
            shutil.rmtree(folder)
        except:
            pass

    await response.edit_text(
        "✅ ʀᴇꜱᴛᴀʀᴛ ᴘʀᴏᴄᴇꜱꜱ ꜱᴛᴀʀᴛᴇᴅ...\nʙᴏᴛ ᴡɪʟʟ ʙᴇ ʙᴀᴄᴋ ɪɴ ᴀ ꜰᴇᴡ ꜱᴇᴄᴏɴᴅꜱ."
    )

    os.system(f"kill -9 {os.getpid()} && bash start")