# ©️ 𝐂𝐨𝐩𝐲𝐫𝐢𝐠𝐡𝐭 (𝐜) 𝟐𝟎𝟐𝟔 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ <@𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨>
# 📍 𝐋𝐨𝐜𝐚𝐭𝐢𝐨𝐧: Maharashtra Aurangabad
#
# ⚖️ 𝐀𝐥𝐥 𝐫𝐢𝐠𝐡𝐭𝐬 𝐫𝐞𝐬𝐞𝐫𝐯𝐞𝐝.
#
# 🔒 𝐓𝐡𝐢𝐬 𝐜𝐨𝐝𝐞 𝐢𝐬 𝐭𝐡𝐞 𝐢𝐧𝐭𝐞𝐥𝐥𝐞𝐜𝐭𝐮𝐚𝐥 𝐩𝐫𝐨𝐩𝐞𝐫𝐭𝐲 𝐨𝐟 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ - <@𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨>.
# 🚫 𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐚𝐥𝐥𝐨𝐰𝐞𝐝 𝐭𝐨 𝐜𝐨𝐩𝐲, 𝐦𝐨𝐝𝐢𝐟𝐲, 𝐫𝐞𝐝𝐢𝐬𝐭𝐫𝐢𝐛𝐮𝐭𝐞, 𝐨𝐫 𝐮𝐬𝐞 𝐭𝐡𝐢𝐬
# 💼 𝐜𝐨𝐝𝐞 𝐟𝐨𝐫 𝐜𝐨𝐦𝐦𝐞𝐫𝐜𝐢𝐚𝐥 𝐨𝐫 𝐩𝐞𝐫𝐬𝐨𝐧𝐚𝐥 𝐩𝐫𝐨𝐣𝐞𝐜𝐭𝐬 𝐰𝐢𝐭𝐡𝐨𝐮𝐭 𝐞𝐱𝐩𝐥𝐢𝐜𝐢𝐭 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧.
#
# ✅ 𝐀𝐥𝐥𝐨𝐰𝐞𝐝:
# 🔱 - 𝐅𝐨𝐫𝐤𝐢𝐧𝐠 𝐟𝐨𝐫 𝐩𝐞𝐫𝐬𝐨𝐧𝐚𝐥 𝐥𝐞𝐚𝐫𝐧𝐢𝐧𝐠
# 📤 - 𝐒𝐮𝐛𝐦𝐢𝐭𝐭𝐢𝐧𝐠 𝐢𝐦𝐩𝐫𝐨𝐯𝐞𝐦𝐞𝐧𝐭𝐬 𝐯𝐢𝐚 𝐩𝐮𝐥𝐥 𝐫𝐞𝐪𝐮𝐞𝐬𝐭𝐬
#
# ❌ 𝐍𝐨𝐭 𝐀𝐥𝐥𝐨𝐰𝐞𝐝:
# 🎭 - 𝐂𝐥𝐚𝐢𝐦𝐢𝐧𝐠 𝐭𝐡𝐢𝐬 𝐜𝐨𝐝𝐞 𝐚𝐬 𝐲𝐨𝐮𝐫 𝐨𝐰𝐧
# 🔄 - 𝐑𝐞-𝐮𝐩𝐥𝐨𝐚𝐝𝐢𝐧𝐠 𝐰𝐢𝐭𝐡𝐨𝐮𝐭 𝐜𝐫𝐞𝐝𝐢𝐭 𝐨𝐫 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧
# 💰 - 𝐒𝐞𝐥𝐥𝐢𝐧𝐠 𝐨𝐫 𝐮𝐬𝐢𝐧𝐠 𝐜𝐨𝐦𝐦𝐞𝐫𝐜𝐢𝐚𝐥𝐥𝐲
#
# 📧 𝐂𝐨𝐧𝐭𝐚𝐜𝐭 𝐟𝐨𝐫 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧𝐬:
# ✉️ 𝐄𝐦𝐚𝐢𝐥: 𝐚𝐥𝐭𝐮𝐪𝟗𝟐@𝐠𝐦𝐚𝐢𝐥.𝐜𝐨𝐦


from pykeyboard import InlineKeyboard
from pyrogram import filters
from pyrogram.types import InlineKeyboardButton, Message

from ZarkoMusicBot import app
from ZarkoMusicBot.utils.database import get_lang, set_lang
from ZarkoMusicBot.utils.decorators import ActualAdminCB, language, languageCB
from config import BANNED_USERS
from strings import get_string, languages_present


def lanuages_keyboard(_):
    keyboard = InlineKeyboard(row_width=2)
    keyboard.add(
        *[
            (
                InlineKeyboardButton(
                    text=languages_present[i],
                    callback_data=f"languages:{i}",
                )
            )
            for i in languages_present
        ]
    )
    keyboard.row(
        InlineKeyboardButton(
            text=_["BACK_BUTTON"],
            callback_data=f"settingsback_helper",
        ),
        InlineKeyboardButton(text=_["CLOSE_BUTTON"], callback_data=f"close"),
    )
    return keyboard


@app.on_message(filters.command(["lang", "setlang", "language"]) & ~BANNED_USERS)
@language
async def langs_command(client, message: Message, _):
    keyboard = lanuages_keyboard(_)
    await message.reply_text(
        _["lang_1"],
        reply_markup=keyboard,
    )


@app.on_callback_query(filters.regex("LG") & ~BANNED_USERS)
@languageCB
async def lanuagecb(client, CallbackQuery, _):
    try:
        await CallbackQuery.answer()
    except:
        pass
    keyboard = lanuages_keyboard(_)
    return await CallbackQuery.edit_message_reply_markup(reply_markup=keyboard)


@app.on_callback_query(filters.regex(r"languages:(.*?)") & ~BANNED_USERS)
@ActualAdminCB
async def language_markup(client, CallbackQuery, _):
    langauge = (CallbackQuery.data).split(":")[1]
    old = await get_lang(CallbackQuery.message.chat.id)
    if str(old) == str(langauge):
        return await CallbackQuery.answer(_["lang_4"], show_alert=True)
    try:
        _ = get_string(langauge)
        await CallbackQuery.answer(_["lang_2"], show_alert=True)
    except:
        _ = get_string(old)
        return await CallbackQuery.answer(
            _["lang_3"],
            show_alert=True,
        )
    await set_lang(CallbackQuery.message.chat.id, langauge)
    keyboard = lanuages_keyboard(_)
    return await CallbackQuery.edit_message_reply_markup(reply_markup=keyboard)


# ═══════════════════════════════════════════════════════════
# ©️ 𝐂𝐨𝐩𝐲𝐫𝐢𝐠𝐡𝐭 𝐑𝐞𝐬𝐞𝐫𝐯𝐞𝐝 - @𝐖𝐡𝐲_𝐍𝐨𝐓_𝐙𝐚𝐫𝐤𝐨 - ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚
# ═══════════════════════════════════════════════════════════
# ©️ 𝟐𝟎𝟐𝟔 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ (@𝐖𝐡𝐘_𝐍𝐨𝐓_𝐙𝐚𝐫𝐊𝐨)
# 🔗 𝐆𝐢𝐭𝐇𝐮𝐛 : 𝐡𝐭𝐭𝐩𝐬://𝐠𝐢𝐭𝐡𝐮𝐛.𝐜𝐨𝐦/𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨/𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# 📢 𝐓𝐞𝐥𝐞𝐠𝐫𝐚𝐦 𝐂𝐡𝐚𝐧𝐧𝐞𝐥 : 𝐡𝐭𝐭𝐩𝐬://𝐭.𝐦𝐞/𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# ═══════════════════════════════════════════════════════════
# ❤️ 𝐋𝐨𝐯𝐞 𝐅𝐫𝐨𝐦 𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# ═══════════════════════════════════════════════════════════ 
