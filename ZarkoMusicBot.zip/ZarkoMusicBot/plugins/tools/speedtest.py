# ©️ 𝐂𝐨𝐩𝐲𝐫𝐢𝐠𝐡𝐭 (𝐜) 𝟐𝟎𝟐𝟔 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ <@𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨>
# 📍 𝐋𝐨𝐜𝐚𝐭𝐢𝐨𝐧: Maharashtra Aurangabad
#
# ⚖️ 𝐀𝐥𝐥 𝐫𝐢𝐠𝐡𝐭𝐬 𝐫𝐞𝐬𝐞𝐫𝐯𝐞𝐝.
#
# 🔒 𝐓𝐡𝐢𝐬 𝐜𝐨𝐝𝐞 𝐢𝐬 𝐭𝐡𝐞 𝐢𝐧𝐭𝐞𝐥𝐥𝐞𝐜𝐭𝐮𝐚𝐥 𝐩𝐫𝐨𝐩𝐞𝐫𝐭𝐲 𝐨𝐟 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ - <@𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨>.
# 🚫 𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐚𝐥𝐥𝐨𝐰𝐞𝐝 𝐭𝐨 𝐜𝐨𝐩𝐲, 𝐦𝐨𝐝𝐢𝐟𝐲, 𝐫𝐞𝐝𝐢𝐬𝐭𝐫𝐢𝐛𝐮𝐭𝐞, 𝐨𝐫 𝐮𝐬𝐞 𝐭𝐡𝐢𝐬
# 💼 𝐜𝐨𝐝𝐞 𝐟𝐨𝐫 𝐜𝐨𝐦𝐦𝐞𝐫𝐜𝐢𝐚𝐥 𝐨𝐫 𝐩𝐞𝐫𝐬𝐨𝐧𝐚𝐥 𝐩𝐫𝐨𝐣𝐞𝐜𝐭𝐬 𝐰𝐢𝐭𝐡𝐨𝐮𝐭 𝐞𝐱𝐩𝐥𝐢𝐜𝐢𝐭 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧.
#
# ✅ 𝐀𝐥𝐥𝐨𝐰𝐞𝐝:
# 🔱 - 𝐅𝐨𝐫𝐤𝐢𝐧𝐠 𝐟𝐨𝐫 𝐩𝐞𝐫𝐬𝐨𝐧𝐚𝐥 𝐥𝐞𝐚𝐫𝐧𝐢𝐧𝐠
# 📤 - 𝐒𝐮𝐛𝐦𝐢𝐭𝐭𝐢𝐧𝐠 𝐢𝐦𝐩𝐫𝐨𝐯𝐞𝐦𝐞𝐧𝐭𝐬 𝐯𝐢𝐚 𝐩𝐮𝐥𝐥 𝐫𝐞𝐪𝐮𝐞𝐬𝐭𝐬
#
# ❌ 𝐍𝐨𝐭 𝐀𝐥𝐥𝐨𝐰𝐞𝐝:
# 🎭 - 𝐂𝐥𝐚𝐢𝐦𝐢𝐧𝐠 𝐭𝐡𝐢𝐬 𝐜𝐨𝐝𝐞 𝐚𝐬 𝐲𝐨𝐮𝐫 𝐨𝐰𝐧
# 🔄 - 𝐑𝐞-𝐮𝐩𝐥𝐨𝐚𝐝𝐢𝐧𝐠 𝐰𝐢𝐭𝐡𝐨𝐮𝐭 𝐜𝐫𝐞𝐝𝐢𝐭 𝐨𝐫 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧
# 💰 - 𝐒𝐞𝐥𝐥𝐢𝐧𝐠 𝐨𝐫 𝐮𝐬𝐢𝐧𝐠 𝐜𝐨𝐦𝐦𝐞𝐫𝐜𝐢𝐚𝐥𝐥𝐲
#
# 📧 𝐂𝐨𝐧𝐭𝐚𝐜𝐭 𝐟𝐨𝐫 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧𝐬:
# ✉️ 𝐄𝐦𝐚𝐢𝐥: 𝐚𝐥𝐭𝐮𝐪𝟗𝟐@𝐠𝐦𝐚𝐢𝐥.𝐜𝐨𝐦


import asyncio

import speedtest
from pyrogram import filters
from pyrogram.types import Message

from ZarkoMusicBot import app
from ZarkoMusicBot.misc import SUDOERS
from ZarkoMusicBot.utils.decorators.language import language


def testspeed(m, _):
    try:
        test = speedtest.Speedtest()
        test.get_best_server()
        m = m.edit_text(_["server_12"])
        test.download()
        m = m.edit_text(_["server_13"])
        test.upload()
        test.results.share()
        result = test.results.dict()
        m = m.edit_text(_["server_14"])
    except Exception as e:
        return m.edit_text(f"<code>{e}</code>")
    return result


@app.on_message(filters.command(["speedtest", "spt"]) & SUDOERS)
@language
async def speedtest_function(client, message: Message, _):
    m = await message.reply_text(_["server_11"])
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, testspeed, m, _)
    output = _["server_15"].format(
        result["client"]["isp"],
        result["client"]["country"],
        result["server"]["name"],
        result["server"]["country"],
        result["server"]["cc"],
        result["server"]["sponsor"],
        result["server"]["latency"],
        result["ping"],
    )
    msg = await message.reply_photo(photo=result["share"], caption=output)
    await m.delete()


# ═══════════════════════════════════════════════════════════
# ©️ 𝐂𝐨𝐩𝐲𝐫𝐢𝐠𝐡𝐭 𝐑𝐞𝐬𝐞𝐫𝐯𝐞𝐝 - @𝐖𝐡𝐲_𝐍𝐨𝐓_𝐙𝐚𝐫𝐤𝐨 - ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚
# ═══════════════════════════════════════════════════════════
# ©️ 𝟐𝟎𝟐𝟔 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ (@𝐖𝐡𝐘_𝐍𝐨𝐓_𝐙𝐚𝐫𝐊𝐨)
# 🔗 𝐆𝐢𝐭𝐇𝐮𝐛 : 𝐡𝐭𝐭𝐩𝐬://𝐠𝐢𝐭𝐡𝐮𝐛.𝐜𝐨𝐦/𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨/𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# 📢 𝐓𝐞𝐥𝐞𝐠𝐫𝐚𝐦 𝐂𝐡𝐚𝐧𝐧𝐞𝐥 : 𝐡𝐭𝐭𝐩𝐬://𝐭.𝐦𝐞/𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# ═══════════════════════════════════════════════════════════
# ❤️ 𝐋𝐨𝐯𝐞 𝐅𝐫𝐨𝐦 𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# ═══════════════════════════════════════════════════════════ 
