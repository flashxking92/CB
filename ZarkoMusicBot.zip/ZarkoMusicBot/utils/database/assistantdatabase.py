# ©️ 𝐂𝐨𝐩𝐲𝐫𝐢𝐠𝐡𝐭 (𝐜) 𝟐𝟎𝟐𝟔 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ <@𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨>
# 📍 𝐋𝐨𝐜𝐚𝐭𝐢𝐨𝐧: Maharashtra Aurangabad
#
# ⚖️ 𝐀𝐥𝐥 𝐫𝐢𝐠𝐡𝐭𝐬 𝐫𝐞𝐬𝐞𝐫𝐯𝐞𝐝.
#
# 🔒 𝐓𝐡𝐢𝐬 𝐜𝐨𝐝𝐞 𝐢𝐬 𝐭𝐡𝐞 𝐢𝐧𝐭𝐞𝐥𝐥𝐞𝐜𝐭𝐮𝐚𝐥 𝐩𝐫𝐨𝐩𝐞𝐫𝐭𝐲 𝐨𝐟 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ - <@𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨>.
# 🚫 𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐚𝐥𝐥𝐨𝐰𝐞𝐝 𝐭𝐨 𝐜𝐨𝐩𝐲, 𝐦𝐨𝐝𝐢𝐟𝐲, 𝐫𝐞𝐝𝐢𝐬𝐭𝐫𝐢𝐛𝐮𝐭𝐞, 𝐨𝐫 𝐮𝐬𝐞 𝐭𝐡𝐢𝐬
# 💼 𝐜𝐨𝐝𝐞 𝐟𝐨𝐫 𝐜𝐨𝐦𝐦𝐞𝐫𝐜𝐢𝐚𝐥 𝐨𝐫 𝐩𝐞𝐫𝐬𝐨𝐧𝐚𝐥 𝐩𝐫𝐨𝐣𝐞𝐜𝐭𝐬 𝐰𝐢𝐭𝐡𝐨𝐮𝐭 𝐞𝐱𝐩𝐥𝐢𝐜𝐢𝐭 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧.
#
# ✅ 𝐀𝐥𝐥𝐨𝐰𝐞𝐝:
# 🔱 - 𝐅𝐨𝐫𝐤𝐢𝐧𝐠 𝐟𝐨𝐫 𝐩𝐞𝐫𝐬𝐨𝐧𝐚𝐥 𝐥𝐞𝐚𝐫𝐧𝐢𝐧𝐠
# 📤 - 𝐒𝐮𝐛𝐦𝐢𝐭𝐭𝐢𝐧𝐠 𝐢𝐦𝐩𝐫𝐨𝐯𝐞𝐦𝐞𝐧𝐭𝐬 𝐯𝐢𝐚 𝐩𝐮𝐥𝐥 𝐫𝐞𝐪𝐮𝐞𝐬𝐭𝐬
#
# ❌ 𝐍𝐨𝐭 𝐀𝐥𝐥𝐨𝐰𝐞𝐝:
# 🎭 - 𝐂𝐥𝐚𝐢𝐦𝐢𝐧𝐠 𝐭𝐡𝐢𝐬 𝐜𝐨𝐝𝐞 𝐚𝐬 𝐲𝐨𝐮𝐫 𝐨𝐰𝐧
# 🔄 - 𝐑𝐞-𝐮𝐩𝐥𝐨𝐚𝐝𝐢𝐧𝐠 𝐰𝐢𝐭𝐡𝐨𝐮𝐭 𝐜𝐫𝐞𝐝𝐢𝐭 𝐨𝐫 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧
# 💰 - 𝐒𝐞𝐥𝐥𝐢𝐧𝐠 𝐨𝐫 𝐮𝐬𝐢𝐧𝐠 𝐜𝐨𝐦𝐦𝐞𝐫𝐜𝐢𝐚𝐥𝐥𝐲
#
# 📧 𝐂𝐨𝐧𝐭𝐚𝐜𝐭 𝐟𝐨𝐫 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧𝐬:
# ✉️ 𝐄𝐦𝐚𝐢𝐥: 𝐚𝐥𝐭𝐮𝐪𝟗𝟐@𝐠𝐦𝐚𝐢𝐥.𝐜𝐨𝐦


import random

from ZarkoMusicBot import userbot
from ZarkoMusicBot.core.mongo import mongodb

db = mongodb.assistants

assistantdict = {}


async def get_client(assistant: int):
    if int(assistant) == 1:
        return userbot.one
    elif int(assistant) == 2:
        return userbot.two
    elif int(assistant) == 3:
        return userbot.three
    elif int(assistant) == 4:
        return userbot.four
    elif int(assistant) == 5:
        return userbot.five


async def save_assistant(chat_id, number):
    number = int(number)
    await db.update_one(
        {"chat_id": chat_id},
        {"$set": {"assistant": number}},
        upsert=True,
    )


async def set_assistant(chat_id):
    from ZarkoMusicBot.core.userbot import assistants

    ran_assistant = random.choice(assistants)
    assistantdict[chat_id] = ran_assistant
    await db.update_one(
        {"chat_id": chat_id},
        {"$set": {"assistant": ran_assistant}},
        upsert=True,
    )
    userbot = await get_client(ran_assistant)
    return userbot


async def get_assistant(chat_id: int) -> str:
    from ZarkoMusicBot.core.userbot import assistants

    assistant = assistantdict.get(chat_id)
    if not assistant:
        dbassistant = await db.find_one({"chat_id": chat_id})
        if not dbassistant:
            userbot = await set_assistant(chat_id)
            return userbot
        else:
            got_assis = dbassistant["assistant"]
            if got_assis in assistants:
                assistantdict[chat_id] = got_assis
                userbot = await get_client(got_assis)
                return userbot
            else:
                userbot = await set_assistant(chat_id)
                return userbot
    else:
        if assistant in assistants:
            userbot = await get_client(assistant)
            return userbot
        else:
            userbot = await set_assistant(chat_id)
            return userbot


async def set_calls_assistant(chat_id):
    from ZarkoMusicBot.core.userbot import assistants

    ran_assistant = random.choice(assistants)
    assistantdict[chat_id] = ran_assistant
    await db.update_one(
        {"chat_id": chat_id},
        {"$set": {"assistant": ran_assistant}},
        upsert=True,
    )
    return ran_assistant


async def group_assistant(self, chat_id: int) -> int:
    from ZarkoMusicBot.core.userbot import assistants

    assistant = assistantdict.get(chat_id)
    if not assistant:
        dbassistant = await db.find_one({"chat_id": chat_id})
        if not dbassistant:
            assis = await set_calls_assistant(chat_id)
        else:
            assis = dbassistant["assistant"]
            if assis in assistants:
                assistantdict[chat_id] = assis
                assis = assis
            else:
                assis = await set_calls_assistant(chat_id)
    else:
        if assistant in assistants:
            assis = assistant
        else:
            assis = await set_calls_assistant(chat_id)
    if int(assis) == 1:
        return self.one
    elif int(assis) == 2:
        return self.two
    elif int(assis) == 3:
        return self.three
    elif int(assis) == 4:
        return self.four
    elif int(assis) == 5:
        return self.five


# ═══════════════════════════════════════════════════════════
# ©️ 𝐂𝐨𝐩𝐲𝐫𝐢𝐠𝐡𝐭 𝐑𝐞𝐬𝐞𝐫𝐯𝐞𝐝 - @𝐖𝐡𝐲_𝐍𝐨𝐓_𝐙𝐚𝐫𝐤𝐨 - ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚
# ═══════════════════════════════════════════════════════════
# ©️ 𝟐𝟎𝟐𝟔 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ (@𝐖𝐡𝐘_𝐍𝐨𝐓_𝐙𝐚𝐫𝐊𝐨)
# 🔗 𝐆𝐢𝐭𝐇𝐮𝐛 : 𝐡𝐭𝐭𝐩𝐬://𝐠𝐢𝐭𝐡𝐮𝐛.𝐜𝐨𝐦/𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨/𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# 📢 𝐓𝐞𝐥𝐞𝐠𝐫𝐚𝐦 𝐂𝐡𝐚𝐧𝐧𝐞𝐥 : 𝐡𝐭𝐭𝐩𝐬://𝐭.𝐦𝐞/𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# ═══════════════════════════════════════════════════════════
# ❤️ 𝐋𝐨𝐯𝐞 𝐅𝐫𝐨𝐦 𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# ═══════════════════════════════════════════════════════════ 
