# ©️ 𝐂𝐨𝐩𝐲𝐫𝐢𝐠𝐡𝐭 (𝐜) 𝟐𝟎𝟐𝟔 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ <@𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨>
# 📍 𝐋𝐨𝐜𝐚𝐭𝐢𝐨𝐧: 𝐒𝐮𝐩𝐚𝐮𝐥, 𝐁𝐢𝐡𝐚𝐫
#
# ⚖️ 𝐀𝐥𝐥 𝐫𝐢𝐠𝐡𝐭𝐬 𝐫𝐞𝐬𝐞𝐫𝐯𝐞𝐝.
#
# 🔒 𝐓𝐡𝐢𝐬 𝐜𝐨𝐝𝐞 𝐢𝐬 𝐭𝐡𝐞 𝐢𝐧𝐭𝐞𝐥𝐥𝐞𝐜𝐭𝐮𝐚𝐥 𝐩𝐫𝐨𝐩𝐞𝐫𝐭𝐲 𝐨𝐟 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ - <@𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨>.
# 🚫 𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐚𝐥𝐥𝐨𝐰𝐞𝐝 𝐭𝐨 𝐜𝐨𝐩𝐲, 𝐦𝐨𝐝𝐢𝐟𝐲, 𝐫𝐞𝐝𝐢𝐬𝐭𝐫𝐢𝐛𝐮𝐭𝐞, 𝐨𝐫 𝐮𝐬𝐞 𝐭𝐡𝐢𝐬
# 💼 𝐜𝐨𝐝𝐞 𝐟𝐨𝐫 𝐜𝐨𝐦𝐦𝐞𝐫𝐜𝐢𝐚𝐥 𝐨𝐫 𝐩𝐞𝐫𝐬𝐨𝐧𝐚𝐥 𝐩𝐫𝐨𝐣𝐞𝐜𝐭𝐬 𝐰𝐢𝐭𝐡𝐨𝐮𝐭 𝐞𝐱𝐩𝐥𝐢𝐜𝐢𝐭 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧.
#
# ✅ 𝐀𝐥𝐥𝐨𝐰𝐞𝐝:
# 🔱 - 𝐅𝐨𝐫𝐤𝐢𝐧𝐠 𝐟𝐨𝐫 𝐩𝐞𝐫𝐬𝐨𝐧𝐚𝐥 𝐥𝐞𝐚𝐫𝐧𝐢𝐧𝐠
# 📤 - 𝐒𝐮𝐛𝐦𝐢𝐭𝐭𝐢𝐧𝐠 𝐢𝐦𝐩𝐫𝐨𝐯𝐞𝐦𝐞𝐧𝐭𝐬 𝐯𝐢𝐚 𝐩𝐮𝐥𝐥 𝐫𝐞𝐪𝐮𝐞𝐬𝐭𝐬
#
# ❌ 𝐍𝐨𝐭 𝐀𝐥𝐥𝐨𝐰𝐞𝐝:
# 🎭 - 𝐂𝐥𝐚𝐢𝐦𝐢𝐧𝐠 𝐭𝐡𝐢𝐬 𝐜𝐨𝐝𝐞 𝐚𝐬 𝐲𝐨𝐮𝐫 𝐨𝐰𝐧
# 🔄 - 𝐑𝐞-𝐮𝐩𝐥𝐨𝐚𝐝𝐢𝐧𝐠 𝐰𝐢𝐭𝐡𝐨𝐮𝐭 𝐜𝐫𝐞𝐝𝐢𝐭 𝐨𝐫 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧
# 💰 - 𝐒𝐞𝐥𝐥𝐢𝐧𝐠 𝐨𝐫 𝐮𝐬𝐢𝐧𝐠 𝐜𝐨𝐦𝐦𝐞𝐫𝐜𝐢𝐚𝐥𝐥𝐲
#
# 📧 𝐂𝐨𝐧𝐭𝐚𝐜𝐭 𝐟𝐨𝐫 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧𝐬:
# ✉️ 𝐄𝐦𝐚𝐢𝐥: 𝐚𝐥𝐭𝐮𝐪𝟗𝟐@𝐠𝐦𝐚𝐢𝐥.𝐜𝐨𝐦

# ═══════════════════════════════════════════════════════════

HELP_1 = """<b><u>ᴀᴅᴍɪɴ ᴄᴏᴍᴍᴀɴᴅꜱ :</b></u>

💠 ᴊᴜꜱᴛ ᴀᴅᴅ <b>ᴄ</b> ɪɴ ᴛʜᴇ ꜱᴛᴀʀᴛɪɴɢ ᴏꜰ ᴛʜᴇ ᴄᴏᴍᴍᴀɴᴅꜱ ᴛᴏ ᴜꜱᴇ ᴛʜᴇᴍ ꜰᴏʀ ᴄʜᴀɴɴᴇʟ.

⏸️ <b>/pause</b> : ᴩᴀᴜꜱᴇ ᴛʜᴇ ᴄᴜʀʀᴇɴᴛ ᴩʟᴀʏɪɴɢ ꜱᴛʀᴇᴀᴍ.

▶️ <b>/resume</b> : ʀᴇꜱᴜᴍᴇ ᴛʜᴇ ᴩᴀᴜꜱᴇᴅ ꜱᴛʀᴇᴀᴍ.

⏩ <b>/skip</b> : ꜱᴋɪᴩ ᴛʜᴇ ᴄᴜʀʀᴇɴᴛ ᴩʟᴀʏɪɴɢ ꜱᴛʀᴇᴀᴍ ᴀɴᴅ ꜱᴛᴀʀᴛ ꜱᴛʀᴇᴀᴍɪɴɢ ᴛʜᴇ ɴᴇxᴛ ᴛʀᴀᴄᴋ ɪɴ Qᴜᴇᴜᴇ.

⛔ <b>/end</b> ᴏʀ <b>/stop</b> : ᴄʟᴇᴀʀꜱ ᴛʜᴇ Qᴜᴇᴜᴇ ᴀɴᴅ ᴇɴᴅ ᴛʜᴇ ᴄᴜʀʀᴇɴᴛ ᴩʟᴀʏɪɴɢ ꜱᴛʀᴇᴀᴍ.

🎮 <b>/player</b> : ɢᴇᴛ ᴀ ɪɴᴛᴇʀᴀᴄᴛɪᴠᴇ ᴩʟᴀʏᴇʀ ᴩᴀɴᴇʟ.

📜 <b>/queue</b> : ꜱʜᴏᴡꜱ ᴛʜᴇ Qᴜᴇᴜᴇᴅ ᴛʀᴀᴄᴋꜱ ʟɪꜱᴛ.
"""

HELP_2 = """
<b><u>ᴀᴜᴛʜ ᴜꜱᴇʀꜱ :</b></u>

👑 ᴀᴜᴛʜ ᴜꜱᴇʀꜱ ᴄᴀɴ ᴜꜱᴇ ᴀᴅᴍɪɴ ʀɪɢʜᴛꜱ ɪɴ ᴛʜᴇ ʙᴏᴛ ᴡɪᴛʜᴏᴜᴛ ᴀᴅᴍɪɴ ʀɪɢʜᴛꜱ ɪɴ ᴛʜᴇ ᴄʜᴀᴛ.

➕ <b>/auth</b> [ᴜꜱᴇʀɴᴀᴍᴇ/ᴜꜱᴇʀ_ɪᴅ] : ᴀᴅᴅ ᴀ ᴜꜱᴇʀ ᴛᴏ ᴀᴜᴛʜ ʟɪꜱᴛ ᴏꜰ ᴛʜᴇ ʙᴏᴛ.
➖ <b>/unauth</b> [ᴜꜱᴇʀɴᴀᴍᴇ/ᴜꜱᴇʀ_ɪᴅ] : ʀᴇᴍᴏᴠᴇ ᴀ ᴀᴜᴛʜ ᴜꜱᴇʀꜱ ꜰʀᴏᴍ ᴛʜᴇ ᴀᴜᴛʜ ᴜꜱᴇʀꜱ ʟɪꜱᴛ.
📋 <b>/authusers</b> : ꜱʜᴏᴡꜱ ᴛʜᴇ ʟɪꜱᴛ ᴏꜰ ᴀᴜᴛʜ ᴜꜱᴇʀꜱ ᴏꜰ ᴛʜᴇ ɢʀᴏᴜᴩ.
"""

HELP_3 = """
<u><b>ʙʀᴏᴀᴅᴄᴀꜱᴛ ꜰᴇᴀᴛᴜʀᴇ</b></u> [👑 ᴏɴʟʏ ꜰᴏʀ ꜱᴜᴅᴏᴇʀꜱ] :

📢 <b>/broadcast</b> [ᴍᴇꜱꜱᴀɢᴇ ᴏʀ ʀᴇᴩʟʏ ᴛᴏ ᴀ ᴍᴇꜱꜱᴀɢᴇ] : ʙʀᴏᴀᴅᴄᴀꜱᴛ ᴀ ᴍᴇꜱꜱᴀɢᴇ ᴛᴏ ꜱᴇʀᴠᴇᴅ ᴄʜᴀᴛꜱ ᴏꜰ ᴛʜᴇ ʙᴏᴛ.

<u>ʙʀᴏᴀᴅᴄᴀꜱᴛɪɴɢ ᴍᴏᴅᴇꜱ :</u>
📌 <b>-pin</b> : ᴩɪɴꜱ ʏᴏᴜʀ ʙʀᴏᴀᴅᴄᴀꜱᴛᴇᴅ ᴍᴇꜱꜱᴀɢᴇꜱ ɪɴ ꜱᴇʀᴠᴇᴅ ᴄʜᴀᴛꜱ.
🔔 <b>-pinloud</b> : ᴩɪɴꜱ ʏᴏᴜʀ ʙʀᴏᴀᴅᴄᴀꜱᴛᴇᴅ ᴍᴇꜱꜱᴀɢᴇ ɪɴ ꜱᴇʀᴠᴇᴅ ᴄʜᴀᴛꜱ ᴀɴᴅ ꜱᴇɴᴅ ɴᴏᴛɪꜰɪᴄᴀᴛɪᴏɴ ᴛᴏ ᴛʜᴇ ᴍᴇᴍʙᴇʀꜱ.
👤 <b>-user</b> : ʙʀᴏᴀᴅᴄᴀꜱᴛꜱ ᴛʜᴇ ᴍᴇꜱꜱᴀɢᴇ ᴛᴏ ᴛʜᴇ ᴜꜱᴇʀꜱ ᴡʜᴏ ʜᴀᴠᴇ ꜱᴛᴀʀᴛᴇᴅ ʏᴏᴜʀ ʙᴏᴛ.
🤖 <b>-assistant</b> : ʙʀᴏᴀᴅᴄᴀꜱᴛ ʏᴏᴜʀ ᴍᴇꜱꜱᴀɢᴇ ꜰʀᴏᴍ ᴛʜᴇ ᴀꜱꜱɪᴛᴀɴᴛ ᴀᴄᴄᴏᴜɴᴛ ᴏꜰ ᴛʜᴇ ʙᴏᴛ.
🚫 <b>-nobot</b> : ꜰᴏʀᴄᴇꜱ ᴛʜᴇ ʙᴏᴛ ᴛᴏ ɴᴏᴛ ʙʀᴏᴀᴅᴄᴀꜱᴛ ᴛʜᴇ ᴍᴇꜱꜱᴀɢᴇ.
↪️ <b>-forward</b> : ꜰᴏʀᴡᴀʀᴅꜱ ᴛʜᴇ ᴍᴇꜱꜱᴀɢᴇ ᴡɪᴛʜ ᴏʀɪɢɪɴᴀʟ ᴄʜᴀɴɴᴇʟ/ᴜꜱᴇʀ ᴀᴛᴛʀɪʙᴜᴛɪᴏɴ.
💬 <b>-wfchat</b> : ꜱᴩᴇᴄɪᴀʟ ʙʀᴏᴀᴅᴄᴀꜱᴛ ᴍᴏᴅᴇ ꜰᴏʀ ᴄʜᴀᴛꜱ (ᴡᴏʀᴋꜱ ᴡɪᴛʜ ʀᴇᴩʟɪᴇᴅ ᴍᴇꜱꜱᴀɢᴇꜱ).
💬 <b>-wfuser</b> : ꜱᴩᴇᴄɪᴀʟ ʙʀᴏᴀᴅᴄᴀꜱᴛ ᴍᴏᴅᴇ ꜰᴏʀ ᴜꜱᴇʀꜱ (ᴡᴏʀᴋꜱ ᴡɪᴛʜ ʀᴇᴩʟɪᴇᴅ ᴍᴇꜱꜱᴀɢᴇꜱ).

<b>📌 ɴᴏᴛᴇ:</b> -ᴡꜰᴄʜᴀᴛ ᴀɴᴅ -ᴡꜰᴜꜱᴇʀ ᴍᴏᴅᴇꜱ ʀᴇQᴜɪʀᴇ ʀᴇᴩʟʏɪɴɢ ᴛᴏ ᴀ ᴍᴇꜱꜱᴀɢᴇ.
"""

HELP_4 = """<u><b>ᴄʜᴀᴛ ʙʟᴀᴄᴋʟɪꜱᴛ ꜰᴇᴀᴛᴜʀᴇ :</b></u> [👑 ᴏɴʟʏ ꜰᴏʀ ꜱᴜᴅᴏᴇʀꜱ]

🚫 ʀᴇꜱᴛʀɪᴄᴛ ꜱʜɪᴛ ᴄʜᴀᴛꜱ ᴛᴏ ᴜꜱᴇ ᴏᴜʀ ᴩʀᴇᴄɪᴏᴜꜱ ʙᴏᴛ.

⚫ <b>/blacklistchat</b> [ᴄʜᴀᴛ ɪᴅ] : ʙʟᴀᴄᴋʟɪꜱᴛ ᴀ ᴄʜᴀᴛ ꜰʀᴏᴍ ᴜꜱɪɴɢ ᴛʜᴇ ʙᴏᴛ.
⚪ <b>/whitelistchat</b> [ᴄʜᴀᴛ ɪᴅ] : ᴡʜɪᴛᴇʟɪꜱᴛ ᴛʜᴇ ʙʟᴀᴄᴋʟɪꜱᴛᴇᴅ ᴄʜᴀᴛ.
📃 <b>/blacklistedchat</b> : ꜱʜᴏᴡꜱ ᴛʜᴇ ʟɪꜱᴛ ᴏꜰ ʙʟᴀᴄᴋʟɪꜱᴛᴇᴅ ᴄʜᴀᴛꜱ.
"""

HELP_5 = """
<u><b>ʙʟᴏᴄᴋ ᴜꜱᴇʀꜱ:</b></u> [👑 ᴏɴʟʏ ꜰᴏʀ ꜱᴜᴅᴏᴇʀꜱ]

🚷 ꜱᴛᴀʀᴛꜱ ɪɢɴᴏʀɪɴɢ ᴛʜᴇ ʙʟᴀᴄᴋʟɪꜱᴛᴇᴅ ᴜꜱᴇʀ, ꜱᴏ ᴛʜᴀᴛ ʜᴇ ᴄᴀɴ'ᴛ ᴜꜱᴇ ʙᴏᴛ ᴄᴏᴍᴍᴀɴᴅꜱ.

🚫 <b>/block</b> [ᴜꜱᴇʀɴᴀᴍᴇ ᴏʀ ʀᴇᴩʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ] : ʙʟᴏᴄᴋ ᴛʜᴇ ᴜꜱᴇʀ ꜰʀᴏᴍ ᴏᴜʀ ʙᴏᴛ.
✅ <b>/unblock</b> [ᴜꜱᴇʀɴᴀᴍᴇ ᴏʀ ʀᴇᴩʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ] : ᴜɴʙʟᴏᴄᴋꜱ ᴛʜᴇ ʙʟᴏᴄᴋᴇᴅ ᴜꜱᴇʀ.
📋 <b>/blockedusers</b> : ꜱʜᴏᴡꜱ ᴛʜᴇ ʟɪꜱᴛ ᴏꜰ ʙʟᴏᴄᴋᴇᴅ ᴜꜱᴇʀꜱ.
"""

HELP_6 = """
<u><b>ᴄʜᴀɴɴᴇʟ ᴩʟᴀʏ ᴄᴏᴍᴍᴀɴᴅꜱ:</b></u>

📺 ʏᴏᴜ ᴄᴀɴ ꜱᴛʀᴇᴀᴍ ᴀᴜᴅɪᴏ/ᴠɪᴅᴇᴏ ɪɴ ᴄʜᴀɴɴᴇʟ.

🎵 <b>/cplay</b> : ꜱᴛᴀʀᴛꜱ ꜱᴛʀᴇᴀᴍɪɴɢ ᴛʜᴇ ʀᴇQᴜᴇꜱᴛᴇᴅ ᴀᴜᴅɪᴏ ᴛʀᴀᴄᴋ ᴏɴ ᴄʜᴀɴɴᴇʟ'ꜱ ᴠɪᴅᴇᴏᴄʜᴀᴛ.
🎬 <b>/cvplay</b> : ꜱᴛᴀʀᴛꜱ ꜱᴛʀᴇᴀᴍɪɴɢ ᴛʜᴇ ʀᴇQᴜᴇꜱᴛᴇᴅ ᴠɪᴅᴇᴏ ᴛʀᴀᴄᴋ ᴏɴ ᴄʜᴀɴɴᴇʟ'ꜱ ᴠɪᴅᴇᴏᴄʜᴀᴛ.
⚡ <b>/cplayforce</b> ᴏʀ <b>/cvplayforce</b> : ꜱᴛᴏᴩꜱ ᴛʜᴇ ᴏɴɢᴏɪɴɢ ꜱᴛʀᴇᴀᴍ ᴀɴᴅ ꜱᴛᴀʀᴛꜱ ꜱᴛʀᴇᴀᴍɪɴɢ ᴛʜᴇ ʀᴇQᴜᴇꜱᴛᴇᴅ ᴛʀᴀᴄᴋ.

🔗 <b>/channelplay</b> [ᴄʜᴀᴛ ᴜꜱᴇʀɴᴀᴍᴇ ᴏʀ ɪᴅ] ᴏʀ [ᴅɪꜱᴀʙʟᴇ] : ᴄᴏɴɴᴇᴄᴛ ᴄʜᴀɴɴᴇʟ ᴛᴏ ᴀ ɢʀᴏᴜᴩ ᴀɴᴅ ꜱᴛᴀʀᴛꜱ ꜱᴛʀᴇᴀᴍɪɴɢ ᴛʀᴀᴄᴋꜱ ʙʏ ᴛʜᴇ ʜᴇʟᴩ ᴏꜰ ᴄᴏᴍᴍᴀɴᴅꜱ ꜱᴇɴᴛ ɪɴ ɢʀᴏᴜᴩ.
"""

HELP_7 = """
<u><b>ɢʟᴏʙᴀʟ ʙᴀɴ ꜰᴇᴀᴛᴜʀᴇ</b></u> [👑 ᴏɴʟʏ ꜰᴏʀ ꜱᴜᴅᴏᴇʀꜱ] :

🌍 <b>/gban</b> [ᴜꜱᴇʀɴᴀᴍᴇ ᴏʀ ʀᴇᴩʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ] : ɢʟᴏʙᴀʟʟʏ ʙᴀɴꜱ ᴛʜᴇ ᴄʜᴜᴛɪʏᴀ ꜰʀᴏᴍ ᴀʟʟ ᴛʜᴇ ꜱᴇʀᴠᴇᴅ ᴄʜᴀᴛꜱ ᴀɴᴅ ʙʟᴀᴄᴋʟɪꜱᴛ ʜɪᴍ ꜰʀᴏᴍ ᴜꜱɪɴɢ ᴛʜᴇ ʙᴏᴛ.
🌍 <b>/ungban</b> [ᴜꜱᴇʀɴᴀᴍᴇ ᴏʀ ʀᴇᴩʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ] : ɢʟᴏʙᴀʟʟʏ ᴜɴʙᴀɴꜱ ᴛʜᴇ ɢʟᴏʙᴀʟʟʏ ʙᴀɴɴᴇᴅ ᴜꜱᴇʀ.
📋 <b>/gbannedusers</b> : ꜱʜᴏᴡꜱ ᴛʜᴇ ʟɪꜱᴛ ᴏꜰ ɢʟᴏʙᴀʟʟʏ ʙᴀɴɴᴇᴅ ᴜꜱᴇʀꜱ.
"""

HELP_8 = """
<b><u>ʟᴏᴏᴘ ꜱᴛʀᴇᴀᴍ :</b></u>

🔄 <b>ꜱᴛᴀʀᴛꜱ ꜱᴛʀᴇᴀᴍɪɴɢ ᴛʜᴇ ᴏɴɢᴏɪɴɢ ꜱᴛʀᴇᴀᴍ ɪɴ ʟᴏᴏᴘ</b>

<b>/loop</b> [enable/disable] : ᴇɴᴀʙʟᴇꜱ/ᴅɪꜱᴀʙʟᴇꜱ ʟᴏᴏᴘ ꜰᴏʀ ᴛʜᴇ ᴏɴɢᴏɪɴɢ ꜱᴛʀᴇᴀᴍ
<b>/loop</b> [1, 2, 3, ...] : ᴇɴᴀʙʟᴇꜱ ᴛʜᴇ ʟᴏᴏᴘ ꜰᴏʀ ᴛʜᴇ ɢɪᴠᴇɴ ᴠᴀʟᴜᴇ.
"""

HELP_9 = """
<u><b>ᴍᴀɪɴᴛᴇɴᴀɴᴄᴇ ᴍᴏᴅᴇ</b></u> [👑 ᴏɴʟʏ ꜰᴏʀ ꜱᴜᴅᴏᴇʀꜱ] :

📜 <b>/logs</b> : ɢᴇᴛ ʟᴏɢꜱ ᴏꜰ ᴛʜᴇ ʙᴏᴛ.

📊 <b>/logger</b> [ᴇɴᴀʙʟᴇ/ᴅɪꜱᴀʙʟᴇ] : ʙᴏᴛ ᴡɪʟʟ ꜱᴛᴀʀᴛ ʟᴏɢɢɪɴɢ ᴛʜᴇ ᴀᴄᴛɪᴠɪᴛɪᴇꜱ ʜᴀᴩᴩᴇɴ ᴏɴ ʙᴏᴛ.

🔧 <b>/maintenance</b> [ᴇɴᴀʙʟᴇ/ᴅɪꜱᴀʙʟᴇ] : ᴇɴᴀʙʟᴇ ᴏʀ ᴅɪꜱᴀʙʟᴇ ᴛʜᴇ ᴍᴀɪɴᴛᴇɴᴀɴᴄᴇ ᴍᴏᴅᴇ ᴏꜰ ʏᴏᴜʀ ʙᴏᴛ.
"""

HELP_10 = """
<b><u>ᴘɪɴɢ & ꜱᴛᴀᴛꜱ :</b></u>

🚀 <b>/start</b> : ꜱᴛᴀʀᴛꜱ ᴛʜᴇ ᴍᴜꜱɪᴄ ʙᴏᴛ.
❓ <b>/help</b> : ɢᴇᴛ ʜᴇʟᴩ ᴍᴇɴᴜ ᴡɪᴛʜ ᴇxᴩʟᴀɴᴀᴛɪᴏɴ ᴏꜰ ᴄᴏᴍᴍᴀɴᴅꜱ.

📡 <b>/ping</b> : ꜱʜᴏᴡꜱ ᴛʜᴇ ᴩɪɴɢ ᴀɴᴅ ꜱʏꜱᴛᴇᴍ ꜱᴛᴀᴛꜱ ᴏꜰ ᴛʜᴇ ʙᴏᴛ.

📊 <b>/stats</b> : ꜱʜᴏᴡꜱ ᴛʜᴇ ᴏᴠᴇʀᴀʟʟ ꜱᴛᴀᴛꜱ ᴏꜰ ᴛʜᴇ ʙᴏᴛ.
"""

HELP_11 = """
<u><b>ᴩʟᴀʏ ᴄᴏᴍᴍᴀɴᴅꜱ :</b></u>

🎬 <b>v :</b> ꜱᴛᴀɴᴅꜱ ꜰᴏʀ ᴠɪᴅᴇᴏ ᴩʟᴀʏ.
⚡ <b>force :</b> ꜱᴛᴀɴᴅꜱ ꜰᴏʀ ꜰᴏʀᴄᴇ ᴩʟᴀʏ.

🎵 <b>/play</b> ᴏʀ <b>/vplay</b> : ꜱᴛᴀʀᴛꜱ ꜱᴛʀᴇᴀᴍɪɴɢ ᴛʜᴇ ʀᴇQᴜᴇꜱᴛᴇᴅ ᴛʀᴀᴄᴋ ᴏɴ ᴠɪᴅᴇᴏᴄʜᴀᴛ.

⚡ <b>/playforce</b> ᴏʀ <b>/vplayforce</b> : ꜱᴛᴏᴩꜱ ᴛʜᴇ ᴏɴɢᴏɪɴɢ ꜱᴛʀᴇᴀᴍ ᴀɴᴅ ꜱᴛᴀʀᴛꜱ ꜱᴛʀᴇᴀᴍɪɴɢ ᴛʜᴇ ʀᴇQᴜᴇꜱᴛᴇᴅ ᴛʀᴀᴄᴋ.
"""

HELP_12 = """
<b><u>ꜱʜᴜꜰꜰʟᴇ Qᴜᴇᴜᴇ :</b></u>

🎲 <b>/shuffle</b> : ꜱʜᴜꜰꜰʟᴇ'ꜱ ᴛʜᴇ Qᴜᴇᴜᴇ.
📜 <b>/queue</b> : ꜱʜᴏᴡꜱ ᴛʜᴇ ꜱʜᴜꜰꜰʟᴇᴅ Qᴜᴇᴜᴇ.
"""

HELP_13 = """
<b><u>ꜱᴇᴇᴋ ꜱᴛʀᴇᴀᴍ :</b></u>

⏩ <b>/seek</b> [ᴅᴜʀᴀᴛɪᴏɴ ɪɴ ꜱᴇᴄᴏɴᴅꜱ] : ꜱᴇᴇᴋ ᴛʜᴇ ꜱᴛʀᴇᴀᴍ ᴛᴏ ᴛʜᴇ ɢɪᴠᴇɴ ᴅᴜʀᴀᴛɪᴏɴ.
⏪ <b>/seekback</b> [ᴅᴜʀᴀᴛɪᴏɴ ɪɴ ꜱᴇᴄᴏɴᴅꜱ] : ʙᴀᴄᴋᴡᴀʀᴅ ꜱᴇᴇᴋ ᴛʜᴇ ꜱᴛʀᴇᴀᴍ ᴛᴏ ᴛʜᴇ ᴛʜᴇ ɢɪᴠᴇɴ ᴅᴜʀᴀᴛɪᴏɴ.
"""

HELP_14 = """
<b><u>ꜱᴏɴɢ ᴅᴏᴡɴʟᴏᴀᴅ</b></u>

🎵 <b>/song</b> [ꜱᴏɴɢ ɴᴀᴍᴇ/ʏᴛ ᴜʀʟ] : ᴅᴏᴡɴʟᴏᴀᴅ ᴀɴʏ ᴛʀᴀᴄᴋ ꜰʀᴏᴍ ʏᴏᴜᴛᴜʙᴇ ɪɴ ᴍᴘ3 ᴏʀ ᴍᴘ4 ꜰᴏʀᴍᴀᴛꜱ.
"""

HELP_15 = """
<b><u>ꜱᴘᴇᴇᴅ ᴄᴏᴍᴍᴀɴᴅꜱ :</b></u>

⚡ ʏᴏᴜ ᴄᴀɴ ᴄᴏɴᴛʀᴏʟ ᴛʜᴇ ᴘʟᴀʏʙᴀᴄᴋ ꜱᴘᴇᴇᴅ ᴏꜰ ᴛʜᴇ ᴏɴɢᴏɪɴɢ ꜱᴛʀᴇᴀᴍ. [ᴀᴅᴍɪɴꜱ ᴏɴʟʏ]

🐌 <b>/speed</b> ᴏʀ <b>/playback</b> : ꜰᴏʀ ᴀᴅᴊᴜꜱᴛɪɴɢ ᴛʜᴇ ᴀᴜᴅɪᴏ ᴘʟᴀʏʙᴀᴄᴋ ꜱᴘᴇᴇᴅ ɪɴ ɢʀᴏᴜᴘ.
🐌 <b>/cspeed</b> ᴏʀ <b>/cplayback</b> : ꜰᴏʀ ᴀᴅᴊᴜꜱᴛɪɴɢ ᴛʜᴇ ᴀᴜᴅɪᴏ ᴘʟᴀʏʙᴀᴄᴋ ꜱᴘᴇᴇᴅ ɪɴ ᴄʜᴀɴɴᴇʟ.
"""

HELP_16 = """
<b><u>ᴘʀɪᴠᴀᴄʏ ᴘᴏʟɪᴄʏ:</b></u>

🔒 <b>/Privacy</b> : Display the privacy statement for Zarko Music Bot 
"""

HELP_17 = """
<b><u>ɢᴀᴍᴇꜱ</b></u>

🎲 <b>/dice</b> : Rᴏʟʟꜱ ᴀ ᴅɪᴄᴇ.
🎯 <b>/ludo</b> : Pʟᴀʏ Lᴜᴅᴏ.
🎯 <b>/dart</b> : Tʜʀᴏᴡꜱ ᴀ ᴅᴀʀᴛ.
🏀 <b>/basket</b> ᴏʀ <b>/basketball</b> : Pʟᴀʏꜱ ʙᴀꜱᴋᴇᴛʙᴀʟʟ.
⚽ <b>/football</b> : Pʟᴀʏꜱ ꜰᴏᴏᴛʙᴀʟʟ.
🎰 <b>/slot</b> ᴏʀ <b>/jackpot</b> : Pʟᴀʏꜱ ᴊᴀᴄᴋᴘᴏᴛ.
🎳 <b>/bowling</b> : Pʟᴀʏꜱ ʙᴏᴡʟɪɴɢ.
"""

HELP_18 = """
<b><u>ᴀᴅᴍɪɴ ᴄᴏᴍᴍᴀɴᴅꜱ</b></u>

🔨 <b>/ban</b> - Ban A User
🚫 <b>/banall</b> - Ban All Users
🗑️ <b>/sban</b> - Delete all messages of user that sended in group and ban the user
⏰ <b>/tban</b> - Ban A User For Specific Time
✅ <b>/unban</b> - Unban A User
⚠️ <b>/warn</b> - Warn A User
🗑️⚠️ <b>/swarn</b> - Delete all the message sended in group and warn the user
🔇 <b>/rmwarns</b> - Remove All Warning of A User
📋 <b>/warns</b> - Show Warning Of A User
👢 <b>/kick</b> - Kick A User
🗑️👢 <b>/skick</b> - Delete the replied message kicking its sender
🧹 <b>/purge</b> - Purge Messages
🧹🔢 <b>/purge [n]</b> - Purge "n" number of messages from replied message
❌ <b>/del</b> - Delete Replied Message
📈 <b>/promote</b> - Promote A Member
👑 <b>/fullpromote</b> - Promote A Member With All Rights
📉 <b>/demote</b> - Demote A Member
📌 <b>/pin</b> - Pin A Message
📍 <b>/unpin</b> - unpin a message
📍📍 <b>/unpinall</b> - unpinall messages
🔇 <b>/mute</b> - Mute A User
⏰🔇 <b>/tmute</b> - Mute A User For Specific Time
🔊 <b>/unmute</b> - Unmute A User
🧟 <b>/zombies</b> - Ban Deleted Accounts
📢 <b>/report</b> | @admins | @admin - Report A Message To Admins.
"""

HELP_19 = """
<b><u>ɪᴍᴀɢᴇ ʟɪɴᴋ ɢᴇɴᴇʀᴀᴛᴏʀ:</b></u>

🖼️ <b>/tgm</b> : ʀᴇᴘʟʏ ᴛᴏ ᴀɴ ᴀɴʏ ɪᴍᴀɢᴇ, ᴠɪᴅᴇᴏ ᴏʀ ɢɪꜰ
"""

HELP_20 = """
<b><u>ᴛᴀɢ ᴄᴏᴍᴍᴀɴᴅꜱ:</b></u>

🏷️ <b>/tagall</b> [ʏᴏᴜʀ ᴍᴇꜱꜱᴀɢᴇ ᴏʀ ʀᴇᴘʟʏ ᴏɴ ᴀɴʏ ᴄʜᴀᴛ] : ᴛᴀɢ ᴀʟʟ ᴜꜱᴇʀꜱ.
👑 <b>/admins</b> [ʏᴏᴜʀ ᴍᴇꜱꜱᴀɢᴇ ᴏʀ ʀᴇᴘʟʏ ᴏɴ ᴀɴʏ ᴄʜᴀᴛ] : ᴛᴀɢ ᴀʟʟ ᴀᴅᴍɪɴꜱ.
"""

HELP_21 = """
<b><u>ᴅᴏᴡɴʟᴏᴀᴅ ᴠɪᴅᴇᴏꜱ:</b></u>

📥 <b>/vid</b> : ᴅᴏᴡɴʟᴏᴀᴅ ᴀɴʏ ɪɴꜱᴛᴀ, ᴛᴡɪᴛᴛᴇʀ ᴀɴᴅ ᴍᴏʀᴇ ᴘʟᴀᴛꜰᴏʀᴍꜱ ᴠɪᴅᴇᴏ.
"""

# 🎯 TEXT TO SPEECH COMMANDS
HELP_22 = """ 🔊 <b>TEXT TO SPEECH</b> 🎤

• <b>/tts</b> &lt;text&gt;: Converts the given text to speech in Hindi 🇮🇳
<b>Example:</b>
• <b>/tts</b> Radhe Radhe 🙏

<b>Note:</b> Make sure to provide some text after the /tts command ✨ """

# 🔗 INVITE LINK COMMANDS  
HELP_23 = """ 🔗 <b>INVITE LINK COMMANDS</b> 💫

• <b>/givelink</b>: Get the invite link for the current chat 📱
• <b>/link</b> group_id: Get information and generate an invite link for the specified group ID 🆔 """

# 🔒 FORCE SUBSCRIPTION COMMANDS
HELP_24 = """ 🔒 <b>FORCE SUBSCRIPTION COMMANDS</b> 🎯

• <b>/fsub</b> &lt;channel username or id&gt; - Set force subscription for this group 📢
• <b>/fsub off</b> - Disable force subscription for this group ❌ """

# 🧟 ZOMBIE ACCOUNTS
HELP_25 = """ 🧟 <b>ZOMBIE ACCOUNTS</b> 💀

• <b>/zombies</b> - Ban Deleted Accounts 🚫 """

# 👤 USER INFORMATION
HELP_26 = """ 👤 <b>USER INFORMATION</b> 📊

• <b>/info</b> [user_id]: Get detailed information about a user 🔍
• <b>/userinfo</b> [user_id]: Alias for /info 👥 """

# 📁 GITHUB REPOSITORY DOWNLOADER
HELP_27 = """ 📁 <b>GITHUB REPOSITORY DOWNLOADER</b> 🐙

<b>Commands Help:</b> 💻
1. <b>/downloadrepo</b> 📥

<b>Description:</b> Download and retrieve files from a GitHub repository 🗂️
<b>Usage:</b> <b>/downloadrepo</b> [Repo_URL] 🔗
<b>Details:</b>
• Clones the specified GitHub repository 📋
• Creates a zip file of the repository 📦
• Sends the zip file back as a document 📄
• If the download fails, an error message will be displayed ⚠️

<b>Examples:</b>
• <b>/downloadrepo</b> https://github.com/username/repository 🌟 """

# 🎲 TRUTH OR DARE BOT COMMANDS
HELP_28 = """ 🎲 <b>TRUTH OR DARE BOT COMMANDS</b> 🎯

Use these commands to play truth or dare: 🎮
• <b>/truth</b>: Get a random truth question. Answer honestly! 💭
• <b>/dare</b>: Get a random dare challenge. Complete it if you dare! 🔥

<b>Examples:</b>
• <b>/truth</b>: "What is your most embarrassing moment?" 😅
• <b>/dare</b>: "Do 10 push-ups." 💪

<b>Note:</b> If you encounter any issues with fetching questions, please try again later ⏰ """

# 🍃 MONGODB CHECKER
HELP_29 = """ 🍃 <b>MONGODB CHECKER</b> 🔍

• <b>/mongochk</b> [mongo_url]: Checks the validity of a MongoDB URL and connection to the MongoDB instance 🗄️ """

# 🔤 FONT CONVERTER
HELP_30 = """ 🔤 <b>FONT CONVERTER</b> ✨

• <b>/font</b> [text] - Converts simple text to beautiful text by changing its font 🎨 """

# 🤬 GALI COMMANDS
HELP_31 = """ 🤬 <b>GALI COMMANDS</b> 😤

<b>Commands:</b>
• <b>/gali</b> - Send random gali (works in DM) 💢
• <b>.gali</b> - Alternative command format 🔥 """

# 🤖 BOT LIST
HELP_32 = """ 🤖 <b>BOT LIST</b> 🎯

• <b>/bots</b> - Get a list of bots in the group 📋 """

# 📝 MARKDOWN HELP
HELP_33 = """ 📝 <b>MARKDOWN HELP</b> 📖

• <b>/markdownhelp</b> - Help about Markdown 🔧 """

# 🏷️ WISH TAG HELP
HELP_34 = """ 🏷️ <b>WISH TAG HELP</b> 🌟

<b>Good Morning:</b> 🌅
• <b>/gmtag</b> - Start Good Morning tagging ☀️
• <b>/gmstop</b> - Stop Good Morning tagging 🛑

<b>Good Afternoon:</b> 🌞
• <b>/gatag</b> - Start Good Afternoon tagging 🌤️
• <b>/gastop</b> - Stop Good Afternoon tagging 🛑

<b>Good Night:</b> 🌙
• <b>/gntag</b> - Start Good Night tagging 🌜
• <b>/gnstop</b> - Stop Good Night tagging 🛑

<b>Utility:</b> ⚙️
• <b>/stopall</b> - Stop all active tagging 🚫
• <b>/taghelp</b> - Show this help message 📖

<b>Note:</b> Only one tagging session can run per chat at a time 📌 """

HELP_35 = """ <b>Welcome Message</b>
• <b>/welcome on/off</b>: Enable or Disable welcome message .
• <b>/awelcome on/off</b>: Enable or Disable Assistant welcome message ."""

HELP_36 = """ 💑 <b>COUPLE OF THE DAY</b> 💖

• <b>/couple</b> - Selects two random members in the group as today's couple ❤️  
• <b>/couples</b> - Same as /couple, shows today's selected couple 💏

📸 Beautiful framed photo with both DPs will be generated 🖼️  
📅 Next couple will be selected automatically tomorrow ⏳ """

HELP_37 = """🤖 <b>ᴀᴠᴀɪʟᴀʙʟᴇ ɪɴ ᴛʜᴇꜱᴇ ʙᴏᴛꜱ</b> 🤖

🔹 <b>ꜰᴜɴᴄᴛɪᴏɴ:</b>  
• <b>ʀᴛᴍᴘꜱ ꜱᴛʀᴇᴀᴍɪɴɢ</b> 🎥

🔹 <b>ᴛʜɪꜱ ꜰᴜɴᴄᴛɪᴏɴ ɪꜱ ꜱᴜᴘᴘᴏʀᴛᴇᴅ ɪɴ:</b>  

• @ZarkoxMusicBoT – <b>𝒁𝑨𝑹𝑲𝑶 Mᴜꜱɪᴄ Bᴏᴛ</b>  

✨ <b>ᴜꜱᴇ ᴛʜᴇꜱᴇ ʙᴏᴛꜱ ᴛᴏ ᴇɴᴊᴏʏ ᴛʜɪꜱ ꜰᴇᴀᴛᴜʀᴇ ꜰᴜʟʟʏ.</b>"""

HELP_38 = """💝 <b>LOVE BIRDS TOOLS</b> 🕊️

🎁 <b>Virtual Gifts:</b>  
• <b>/gifts</b> - <b>ꜱʜᴏᴡ ᴀʟʟ ᴀᴠᴀɪʟᴀʙʟᴇ ɢɪꜰᴛꜱ</b> 🎀  
• <b>/sendgift</b> @user 🌹 - <b>ꜱᴇɴᴅ ᴀ ɢɪꜰᴛ ᴛᴏ ꜱᴏᴍᴇᴏɴᴇ</b> 💌  
• <b>/mygifts</b> - <b>ᴠɪᴇᴡ ʏᴏᴜʀ ʀᴇᴄᴇɪᴠᴇᴅ ɢɪꜰᴛꜱ</b> 📥  

💰 <b>Balance & Coins:</b>  
• <b>/balance</b> (or /bal) - <b>ᴄʜᴇᴄᴋ ʏᴏᴜʀ ᴄᴏɪɴꜱ, ɢɪꜰᴛꜱ ꜱᴇɴᴛ & ʀᴇᴄᴇɪᴠᴇᴅ</b> 💸  
• (auto) - <b>ᴇᴀʀɴ ᴄᴏɪɴꜱ ᴀᴜᴛᴏᴍᴀᴛɪᴄᴀʟʟʏ ʙʏ ᴄʜᴀᴛᴛɪɴɢ & ᴄʟᴀɪᴍɪɴɢ ɢɪꜰᴛꜱ</b> ✨  

📖 <b>Love Stories:</b>  
• <b>/story</b> Name1 Name2 - <b>ɢᴇɴᴇʀᴀᴛᴇ ᴀ ʀᴀɴᴅᴏᴍ ʀᴏᴍᴀɴᴛɪᴄ ꜱᴛᴏʀʏ</b> 💞  

🏆 <b>Leaderboard:</b>  
• <b>/top</b> (or /leaderboard) - <b>ꜱʜᴏᴡ ʀɪᴄʜᴇꜱᴛ ᴜꜱᴇʀꜱ ᴡɪᴛʜ ᴍᴏꜱᴛ ᴄᴏɪɴꜱ</b> 🏅  

💡 <b>Tips:</b>  
- <b>ꜱᴇɴᴅ ᴍᴇꜱꜱᴀɢᴇꜱ ᴛᴏ ᴇᴀʀɴ ᴄᴏɪɴꜱ</b> 📩  
- <b>ᴄʟᴀɪᴍ ᴘᴇɴᴅɪɴɢ ɢɪꜰᴛꜱ ᴡʜᴇɴ ʏᴏᴜ ᴄʜᴀᴛ</b> 🎁  
- <b>ꜱᴘʀᴇᴀᴅ ʟᴏᴠᴇ & ᴄʟɪᴍʙ ᴛʜᴇ ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅ</b> ❤️
"""

HELP_39 = """🎤 <b>VC LOGGER</b> 📢

🔔 <b>Voice Chat Notifications:</b>  
- <b>/vclogger</b> - <b>ᴄʜᴇᴄᴋ ᴠᴄ ʟᴏɢɢᴇʀ ꜱᴛᴀᴛᴜꜱ</b> 📊  
- <b>/vclogger on</b> - <b>ᴇɴᴀʙʟᴇ ᴠᴄ ʟᴏɢɢɪɴɢ</b> ✅  
- <b>/vclogger off</b> - <b>ᴅɪꜱᴀʙʟᴇ ᴠᴄ ʟᴏɢɢɪɴɢ</b> 🚫  

📝 <b>Alternative Commands:</b>  
- <b>/vclogger enable</b> - <b>ᴛᴜʀɴ ᴏɴ ɴᴏᴛɪꜰɪᴄᴀᴛɪᴏɴꜱ</b> 🔊  
- <b>/vclogger disable</b> - <b>ᴛᴜʀɴ ᴏꜰꜰ ɴᴏᴛɪꜰɪᴄᴀᴛɪᴏɴꜱ</b> 🔇  
- <b>/vclogger yes/no</b> - <b>ǫᴜɪᴄᴋ ᴛᴏɢɢʟᴇ</b> ⚡  

✨ <b>Features:</b>  
- <b>ʀᴇᴀʟ-ᴛɪᴍᴇ ᴊᴏɪɴ/ʟᴇᴀᴠᴇ ɴᴏᴛɪꜰɪᴄᴀᴛɪᴏɴꜱ</b> 🎵  
- <b>ᴀᴜᴛᴏ-ᴅᴇʟᴇᴛᴇ ᴍᴇꜱꜱᴀɢᴇꜱ (10 ꜱᴇᴄ)</b> ⏱️  
- <b>ʀᴀɴᴅᴏᴍ ᴡᴇʟᴄᴏᴍᴇ/ɢᴏᴏᴅʙʏᴇ ᴍᴇꜱꜱᴀɢᴇꜱ</b> 💬  
- <b>ᴘᴇʀꜱɪꜱᴛᴇɴᴛ ꜱᴇᴛᴛɪɴɢꜱ (ꜱᴀᴠᴇᴅ ɪɴ ᴅᴀᴛᴀʙᴀꜱᴇ)</b> 💾  

💡 <b>Tips:</b>  
- <b>ᴏɴʟʏ ᴀᴅᴍɪɴꜱ ᴄᴀɴ ᴛᴏɢɢʟᴇ ᴛʜɪꜱ ꜰᴇᴀᴛᴜʀᴇ</b> 👑  
- <b>ᴋᴇᴇᴘꜱ ʏᴏᴜʀ ɢʀᴏᴜᴘ ʟɪᴠᴇʟʏ & ɪɴꜰᴏʀᴍᴇᴅ</b> 🎉  
- <b>ᴡᴏʀᴋꜱ ᴡɪᴛʜ ᴀʟʟ ᴘʀᴇꜰɪxᴇꜱ (., !, /, @, ?, ')</b> 🔧
"""

# ═══════════════════════════════════════════════════════════
# ©️ 𝐂𝐨𝐩𝐲𝐫𝐢𝐠𝐡𝐭 𝐑𝐞𝐬𝐞𝐫𝐯𝐞𝐝 - @𝐖𝐡𝐲_𝐍𝐨𝐓_𝐙𝐚𝐫𝐤𝐨 - ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚
# ═══════════════════════════════════════════════════════════
# ©️ 𝟐𝟎𝟐𝟔 ⚚ 𝒁𝑨𝑹𝑲𝑶 ⚚ (@𝐖𝐡𝐘_𝐍𝐨𝐓_𝐙𝐚𝐫𝐊𝐨)
# 🔗 𝐆𝐢𝐭𝐇𝐮𝐛 : 𝐡𝐭𝐭𝐩𝐬://𝐠𝐢𝐭𝐡𝐮𝐛.𝐜𝐨𝐦/𝐖𝐡𝐲_𝐧𝐨𝐭_𝐳𝐚𝐫𝐤𝐨/𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# 📢 𝐓𝐞𝐥𝐞𝐠𝐫𝐚𝐦 𝐂𝐡𝐚𝐧𝐧𝐞𝐥 : 𝐡𝐭𝐭𝐩𝐬://𝐭.𝐦𝐞/𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# ═══════════════════════════════════════════════════════════
# ❤️ 𝐋𝐨𝐯𝐞 𝐅𝐫𝐨𝐦 𝐙𝐚𝐫𝐤𝐨𝐌𝐮𝐬𝐢𝐜𝐁𝐨𝐭
# ═══════════════════════════════════════════════════════════